<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>404 Error</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Cool 404 Page Widget Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="<?php echo DOMAIN; ?>assets/error/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='//fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
</head>
<body>
	<div class="main">
		<div class="nav_w3l">
			<ul>
				
			</ul>
		</div>
		<h1>404</h1>
		<h2>ooops, something went wrong. Page not found.</h2>
		<div class="more_w3ls">
			<?php /*?><a href="index.html">Try Once Again</a><?php */?>
		</div>
		<div class="wthree_social_icons">
			<div>
				<?php /*?><a href="#"><span>Facebook</span></a>
				<a href="#"><span>Twitter</span></a>
				<a href="#"><span>Tumblr</span></a>
				<a href="#"><span>LinkedIn</span></a>
				<a href="#"><span>Vimeo</span></a><?php */?>
			</div>
		</div>
		<div class="copyright">
			<p>© Cheapest Limos . All rights Reserved.Powered by A2Z Online Solution. reserved.</p>
		</div>
	</div>
</body>
</html>