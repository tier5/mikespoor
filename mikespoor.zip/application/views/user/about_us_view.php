<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <base href="<?php echo DOMAIN; ?>">
<title><?php echo $title; ?></title>
        <meta name="description" content="<?php echo $metainfo['meta_description'];?>" />
<meta name="keywords" content="<?php echo $metainfo['meta_keywords'];?>" />
        <meta name="viewport" content="initial-scale=1, maximum-scale=1, width=device-width">

        <!-- stylesheets -->
        <link rel="stylesheet" href="assets/user/css/grid.css" />
        <link rel="stylesheet" href="assets/user/css/style.css" />
        <link rel="stylesheet" href="assets/user/css/darkblue.css" />
        <link rel="stylesheet" href="assets/user/css/responsive.css" />
        <link rel="stylesheet" href="assets/user/css/animate.css" />
        <link rel="stylesheet" href="assets/user/css/retina.css" />

        <!-- google web fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;subset=latin,latin-ext,cyrillic-ext' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Raleway:400,300,500,600,700,800,900,200,100' rel='stylesheet' type='text/css'>

        <!-- Icons -->
        <link rel="stylesheet" href="assets/user/pixons/style.css" />
        <link rel="stylesheet" href="assets/user/iconsfont/iconsfont.css" />
        
        <link rel="stylesheet" href="assets/user/style-switcher/styleSwitcher.css"/>

        <!--[if lt IE 9]>
            <script src="js/html5shiv.js"></script>
        <![endif]-->

        <!--[if lt IE 9]>
            <script src="js/selectivizr-min.js"></script>
        <![endif]-->
<link href="assets/user/css/flaticon.css" rel="stylesheet" type="text/css" media="screen">

    </head>

    <body>
        <!-- style switcher start -->
        <!-- style switcher end -->
        
        <!-- .header-wrapper start -->
        <?php include('include/header.php'); ?>
        <!-- .header-wrapper end -->

        <!-- #page-title start -->
        <section id="page-title" class="page-title-1" data-stellar-background-ratio="0.5" >
            <div class="container">
                <div class="row">
                    <div class="grid_8">
                        <div class="pt-title triggerAnimation animated" data-animate="fadeInLeft">
                           <!-- <h1>We are <span class="strong">Creative</span> web agency <br />
                                and leaders in Web design industry.</h1>-->
                        </div>
                    </div><!-- .grid_8 end -->

                    <!-- .grid_4 start -->
                    <div class="grid_4">
                        <div class="pt-image-container" >
                            <!--<div class="pt-image triggerAnimation animated" data-animate="fadeInRight">
                                <img class="float-right" src="img/page-titles/about-page-title.png" alt="about us page title image" />
                            </div>-->
                        </div>
                    </div><!-- .grid_4 end -->
                </div><!-- .row end -->

                <div class="row">
                    <div class="grid_8">
                        <div class="breadcrumbs triggerAnimation animated" data-animate="fadeInUp">
                            <!--<ul>
                                <li>
                                    <span>You are here:</span>
                                </li>

                                <li>
                                    <a href="portfolio3.html">Pages / </a>
                                </li>

                                <li>
                                    <span class="active">About us</span>
                                </li>
                            </ul>-->
                        </div>
                    </div>
                </div>
            </div><!-- .container end -->
        </section><!-- #page-title end -->

<?php
if($aboutinfo['cms_choice']=='0')
{
?>
        <!-- .page-content start -->
        <section class="page-content">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <div class="grid_6">
                        <div class="triggerAnimation animated" data-animate="fadeInLeft">
                            <ul class="team-alternative">
                                <li class="team-member">
                                    <img src="<?php echo DOMAIN.'uploads/'.$aboutinfo['cms_aimage1']; ?>" alt="team member image"/>

                                    <div class="team-member-hover">
                                        <div class="mask"></div>

                                        <div class="team-member-info">
                                            <h5>Alicia Stewark</h5>
                                            <span class="position">Company CEO</span>
                                            <a href="aboutme.html" class="btn-medium empty white">Read more</a>
                                        </div>
                                    </div>
                                </li>

                                <li class="team-member">
                                    <img src="<?php echo DOMAIN.'uploads/'.$aboutinfo['cms_aimage2']; ?>" alt="team member image"/>

                                    <div class="team-member-hover">
                                        <div class="mask"></div>

                                        <div class="team-member-info">
                                            <h5>Peter Brown</h5>
                                            <span class="position">Senior web developer</span>
                                            <a href="aboutme.html" class="btn-medium empty white">Read more</a>
                                        </div>
                                    </div>
                                </li>

                                <li class="team-member">
                                    <img src="<?php echo DOMAIN.'uploads/'.$aboutinfo['cms_aimage3']; ?>" alt="team member image"/>

                                    <div class="team-member-hover">
                                        <div class="mask"></div>

                                        <div class="team-member-info">
                                            <h5>Brooke Felther</h5>
                                            <span class="position">Customer relations</span>
                                            <a href="aboutme.html" class="btn-medium empty white">Read more</a>
                                        </div>
                                    </div>
                                </li>

                                <li class="team-member">
                                    <img src="<?php echo DOMAIN.'uploads/'.$aboutinfo['cms_aimage4']; ?>" alt="team member image"/>

                                    <div class="team-member-hover">
                                        <div class="mask"></div>

                                        <div class="team-member-info">
                                            <h5>Tom Harting</h5>
                                            <span class="position">Senior manager</span>
                                            <a href="aboutme.html" class="btn-medium empty white">Read more</a>
                                        </div>
                                    </div>
                                </li>                                
                            </ul>
                        </div><!-- .triggerAnimation.animated end -->
                    </div><!-- .grid_6 end -->

                    <!-- .grid_6 start -->
                    <article class="grid_6">
                        <div class="triggerAnimation animated" data-animate="fadeInRight">
                            <section class="heading-bordered">
                                <h3><?php echo $aboutinfo['cms_title']; ?> <b>dolor</b> </h3>
                            </section><!-- .heading-bordered end -->

                            <?php echo htmlspecialchars_decode($aboutinfo['cms_content']); ?>

                            
                        </div><!-- .triggerAnimation.animated end -->
                    </article><!-- .grid_6 end -->
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section>
       <?php
}
else if($aboutinfo['cms_choice']=='1')
{
?>
        
        <section class="page-content">
            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <div class="grid_12" align="center">
                       <div id="pdf">
  <object width="90%" height="1425" type="application/pdf" data="assets/images/sample.pdf?#view=FitH&scrollbar=0&toolbar=0&navpanes=0" id="pdf_content">
    <p>It appears your Web browser is not configured to display PDF files.</p>
  </object>
</div>
                    </div><!-- .grid_6 end -->

                    <!-- .grid_6 start -->
                   
                </div><!-- .row end -->
            </div><!-- .container end -->
        </section>
        <?php
}
?>
        <!-- .page-content end -->

        <!-- .page-content start -->
        <section class="page-content parallax parallax-1" data-stellar-background-ratio="0.5">

            <!-- .container start -->
            <div class="container">
                <!-- .row start -->
                <div class="row">
                    <article class="grid_12">
                        <section class="heading-centered triggerAnimation animated" data-animate="bounceIn">
                            <h2 style="margin-bottom:32px;"><?php echo $aboutinfo['cms_title']; ?> </h2>
                           <?php echo htmlspecialchars_decode($aboutinfo['cms_fcontent']); ?>
                        </section>
                    </article><!-- .grid_12 end -->
                </div><!-- .row end -->

                <!-- .row start -->
                <!-- .row end -->
            </div><!-- .container end -->
        </section><!-- .page-content end -->

        <!-- .page-content end -->

        <!-- .page-content.parallax start -->
        <!-- .page-content.parallax.parallax-2 end -->

        <!-- .page-content end -->

        <!-- .footer-wrapper start -->
        <?php include('include/footer.php'); ?><!-- .footer-wrapper end -->

        <!-- scripts -->
        <script  src="assets/user/js/jquery-1.9.1.js"></script> <!-- jQuery library -->  
        <script  src="assets/user/js/jquery-migrate-1.2.1.min.js"></script> <!-- jQuery migrate -->
        <script  src="assets/user/js/jquery.placeholder.min.js"></script><!-- jQuery placeholder fix for old browsers -->
        <script  src="assets/user/js/modernizr.custom.js"></script> <!-- jQuery modernizr -->
        <script  src="assets/user/js/jquery.dlmenu.js"></script><!-- responsive navigation -->
        <script  src="assets/user/js/waypoints.min.js"></script><!-- js for animating content -->
        <script  src="assets/user/js/retina-1.1.0.min.js"></script><!-- retina ready script -->
        <script  src="assets/user/js/jquery.stellar.min.js"></script><!-- parallax scrolling -->
        <script  src="assets/user/js/jquery.tweetscroll.js"></script> <!-- jQuery tweetscroll plugin -->
        <script  src="assets/user/js/jquery.carouFredSel-6.2.1-packed.js"></script><!-- CarouFredSel carousel plugin -->
        <script  src="assets/user/js/jquery.touchSwipe-1.6.js"></script><!-- TouchSwipe plugin -->
        <script  src="assets/user/js/easypiechart.js"></script><!-- Easy Pie Chart plugin -->
        <script  src="assets/user/style-switcher/styleSwitcher.js"></script>
		<script  src="assets/user/js/nicescroll.min.js"></script> <!-- Nice scroll Plugin -->
        <script  src="assets/user/js/include.js"></script> <!-- jQuery custom options -->

        <script>
            /* <![CDATA[ */
            jQuery(document).ready(function($) {
                'use strict';

                $('.skills-bar').waypoint(function() {
                    $('.skills li span').addClass('expand');
                },
                        {offset: '70%'}
                );

                // Easy Pie Chart plugin - skills
                var chartSize = '110';

                $('.load-skills').waypoint(function() {
                    $('.easy-pie-chart').easyPieChart({
                        animate: 1000,
                        scaleColor: false,
                        lineWidth: 3,
                        lineCap: 'square',
                        size: chartSize,
                        trackColor: '#e5e5e5',
                        barColor: '#727c89'
                    });
                },
                        {offset: '60%'}
                );

                //  Responsive layout, resizing the items
                $('#testimonial-carousel').carouFredSel({
                    responsive: true,
                    width: '100%',
                    auto: true,
                    scroll: 1,
                    swipe: {
                        onMouse: true,
                        onTouch: true
                    },
                    items: {
                        width: '370',
                        height: 'variable',
                        visible: {
                            min: 1,
                            max: 1
                        }
                    }
                });

                //  Responsive layout, resizing the items
                $('#client-carousel').carouFredSel({
                    responsive: true,
                    width: '100%',
                    height: '100%',
                    auto: false,
                    scroll: 1,
                    swipe: {
                        onMouse: true,
                        onTouch: true
                    },
                    prev: '.c_prev',
                    next: '.c_next',
                    items: {
                        width: 170,
                        height: '100%',
                        visible: {
                            min: 1,
                            max: 6
                        }
                    }
                });


            });

            /* ]]> */
        </script>
    </body>
</html>
