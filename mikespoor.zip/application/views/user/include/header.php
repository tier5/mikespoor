<?php
	  
	 $actual_link = basename($_SERVER["REQUEST_URI"]);
	 //$acarr=explode("backend/",$actual_link);
	 
	 if(isset($actual_link))
	 {
		 $current_page=$actual_link;
		
	 }
	 else
	 {
		  $current_page='home';
	 }
	
	 //echo "<h1>".$current_page."</h1>";
	 ?>
<div id="header-wrapper" class="clearfix" >
            <!-- .top-bar start -->
            <section id="top-bar-wrapper" style="background-color:<?php echo $companyinfo['theme_color']; ?>;">
                <div id="top-bar" class="clearfix">
                    <ul class="contact-info">
                        <li>
                            <i class="flaticon-telephone66"></i>
                            <span><a href="tel:<?php echo $companyinfo['contact_no1']; ?>"><?php echo $companyinfo['contact_no1']; ?></a></span>
                        </li>

                        <li>
                            <i class="flaticon-envelope4"></i>
                            <span><a href="mailto:<?php echo $companyinfo['contact_email']; ?>"><?php echo $companyinfo['contact_email']; ?></a></span>
                        </li>
                    </ul><!-- .contact-info end -->

                    <!--- .social-links start -->
                    <ul class="social-links">
                        <li>
                            <a target="_blank" href="<?php echo $companyinfo['twitter_link']; ?>" class="flaticon-twitter16"></a>
                        </li>

                        <li>
                            <a target="_blank" href="<?php echo $companyinfo['facebook_link']; ?>" class="flaticon-facebook25"></a>
                        </li>

                        <li>
                            <a target="_blank" href="<?php echo $companyinfo['google_link']; ?>" class="flaticon-google26"></a>
                        </li>

                        <!--<li>
                            <a href="#" class="pixons-skype"></a>
                        </li>-->
                    </ul><!-- .social-links end -->
                </div><!-- .top-bar end -->
            </section><!-- .top-bar-wrapper end -->

            <!-- #header start -->
            <header id="header" class="clearfix">
                <section id="logo">
                    <a href="index.html">
                        <img src="<?php echo DOMAIN.'uploads/'.$companyinfo['company_logo']; ?>" title="<?php echo $companyinfo['company_name']; ?>" alt="company logo"/>
                    </a>
                </section>

                <section id="nav-container">
                    <nav id="nav">
                        <ul>
                            <li>
                                <a href="<?php echo DOMAIN; ?>">HOME</a>
                              
                            </li>

                            <li <?php if($current_page == 'about-us') { ?>class="current-menu-item"<?php } ?>>
                                <a href="<?php echo DOMAIN; ?>about-us">ABOUT MIKE</a>
                               
                            </li>

                            <li <?php if($current_page == 'picture-gallery') { ?>class="current-menu-item"<?php } ?>>
                                <a href="<?php echo DOMAIN; ?>picture-gallery">PICTURE GALLERY</a>
                                <!--<ul>
                                    <li><a href="static_website.html">Static Website</a></li>
                                    <li><a href="#">Dynamic Website</a></li>
                                    <li><a href="#">Ecommerce Website</a></li>
                                    <li><a href="#">App Development</a></li>
                                    <li><a href="#">Print Media</a></li>
                                    <li><a href="#">Hosting</a></li>
                                    <li><a href="#">Other Top Ups</a></li>
                                    
                                </ul>-->
                            </li>
 <li <?php if($current_page == 'video-gallery') { ?>class="current-menu-item"<?php } ?>>
                                <a href="<?php echo DOMAIN; ?>video-gallery">VIDEO GALLERY</a>
                                <!--<ul>
                                    <li><a href="#">Google Local Listing</a></li>
                                    <li><a href="#">SEO</a></li>
                                    <li><a href="#">SMO</a></li>
                                    <li><a href="#">Reputation Management</a></li>
                                    <li><a href="#">Digital Marketing</a></li>
                                   
                                </ul>-->
                            </li>
                            <li <?php if($current_page == 'links-news') { ?>class="current-menu-item"<?php } ?>>
                                <a href="<?php echo DOMAIN; ?>links-news">LINKS & NEWS</a>
                              </li>
                               
                               <li <?php if($current_page == 'school-visit') { ?>class="current-menu-item"<?php } ?>>
                                <a href="<?php echo DOMAIN; ?>school-visit">SCHOOL VISIT</a>
                              </li>
                              
                              
								<li <?php if($current_page == 'contact') { ?>class="current-menu-item"<?php } ?> class="no-sub">
                                <a href="<?php echo DOMAIN; ?>contact">CONTACT</a>
                            </li>
                        </ul>
                    </nav><!-- #nav end -->                  
                </section><!-- #nav-container end -->

                <!-- #dl-menu.dl-menuwrapper start -->
                <div id="dl-menu" class='dl-menuwrapper'>
                    <button class="dl-trigger">Open Menu</button>
                    <ul class="dl-menu">
                        <li>
                            <a href="index.html">Home</a>
                            <ul class="dl-submenu">
                                <li><a href="index.html">Home default</a></li>
                                <li><a href="home02.html">Home business 02</a></li>
                                <li><a href="home03.html">Home business 03</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="index.html">Headers</a>
                            <ul class="dl-submenu">
                                <li><a href="index.html">Header default</a></li>
                                <li><a href="header02.html">Header style 02</a></li>
                                <li><a href="header03.html">Header style 03</a></li>
                                <li><a href="header04.html">Header style 04</a></li>
                                <li><a href="header05.html">Header style 05</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="about.html">Pages</a>
                            <ul class="dl-submenu">
                                <li><a href="about.html">About us</a></li>
                                <li><a href="about02.html">About us style 02</a></li>
                                <li><a href="aboutme.html">About me</a></li>
                                <li><a href="pagetitle02.html">About me page title 02</a></li>
                                <li><a href="pagetitle03.html">About me page title 03</a></li>
                                <li><a href="team.html">Team members</a></li>
                                <li><a href="hiring.html">We are hiring</a></li>
                                <li><a href="services.html">Our services</a></li>
                                <li><a href="services02.html">Services style 02</a></li>
                                <li><a href="pricing.html">Pricing tables</a></li>
                                <li><a href="sidebarleft.html">Page sidebar left</a></li>
                                <li><a href="sidebarright.html">Page sidebar right</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="portfolio3.html">Portfolio</a>
                            <ul class="dl-submenu">
                                <li><a href="portfolio2.html">Portfolio 2 columns</a></li>
                                <li><a href="portfolio3.html">Portfolio 3 columns</a></li>
                                <li><a href="portfolio4.html">Portfolio 4 columns</a></li>
                                <li><a href="portfoliofull.html">Portfolio full layout</a></li>
                                <li><a href="portfoliosingle.html">Portfolio single</a></li>
                                <li><a href="portfoliosingle02.html">Portfolio single 02</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="blog2.html">Blog</a>
                            <ul class="dl-submenu">
                                <li><a href="blog.html">Blog small image</a></li>
                                <li><a href="blog2.html">Blog big image</a></li>
                                <li><a href="blog3.html">Blog full no sidebar</a></li>
                                <li><a href="blogmasonry.html">Blog masonry</a></li>
                                <li><a href="blogmasonry02.html">Blog masonry no sidebar</a></li>
                                <li><a href="blogsingle.html">Blog single</a></li>
                                <li><a href="blogsingle02.html">Blog single full width</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="#">Features</a>
                            <ul class="dl-submenu">
                                <li><a href="tabs.html">Tabs</a></li>
                                <li><a href="buttons.html">Buttons</a></li>
                                <li><a href="accordions.html">Accordions</a></li>
                                <li><a href="informationboxes.html">Information boxes</a></li>
                                <li><a href="testimonials.html">Testimonials</a></li>
                                <li><a href="lists.html">Lists</a></li>
                                <li><a href="notes.html">Notes</a></li>
                                <li><a href="columnsandsections.html">Columns and sections</a></li>
                                <li><a href="dropcaps.html">Dropcaps & highlighters</a></li>
                                <li><a href="socialicons.html">Social icons</a></li>
                                <li><a href="socialphotostreams.html">Social photo streams</a></li>
                            </ul>
                        </li>

                        <li><a href="contact.html">Contact</a></li>
                    </ul><!-- .dl-menu end -->
                </div><!-- #dl-menu.dl-menuwrapper end -->

                <!-- #search-box start -->
                <!--<section id="search">
                    <form action="#" method="get">
                        <input class="search-submit" type="submit" />
                        <input id="m_search" name="s" type="text" placeholder="Type and hit enter..." />                        
                    </form>
                </section>--><!-- #search-box end -->
            </header>
            <!-- .header end -->        
        </div>