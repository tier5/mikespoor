<footer class="main-footer">
    <div class="pull-right hidden-xs">
      
    </div>
    <strong><?php if(isset($companyinfo['footer_message'])){echo $companyinfo['footer_message'];} ?> & This site is Designed & Developed by</font> <a target="_blank" href="http://www.a2zonlinesolution.org/"> A2Z ONLINE SOLUTION</a></strong>
    
  </footer>